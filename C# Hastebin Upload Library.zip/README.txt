This is a C# Visual Studio Library for uploading text to hasteb.in and getting the link.

usage example:

using HastebinAPI;      <---- Import
using System;
using System.Linq;
using System.Text;

namespace HasteBinTest
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.Write(Handler.uploadTextAndGetLink("horso skidder", false));   <---- Usage
	    Console.ReadLine();

        }
    }
}
